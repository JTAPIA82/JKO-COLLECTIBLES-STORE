
window.PRODUCTS = [
  { id: 1, name: "Rare Trading Card A", price: 9.99, img: "https://via.placeholder.com/150" },
  { id: 2, name: "Collectible Toy B", price: 19.99, img: "https://via.placeholder.com/150" },
  { id: 3, name: "Limited Figure C", price: 29.99, img: "https://via.placeholder.com/150" }
];
