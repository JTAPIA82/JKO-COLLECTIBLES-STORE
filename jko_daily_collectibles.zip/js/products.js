
window.PRODUCTS = [
  { id: 1, name: "Rare Trading Card A", price: 9.99, img: "https://via.placeholder.com/200x200?text=Card+A" },
  { id: 2, name: "Collectible Toy B", price: 19.99, img: "https://via.placeholder.com/200x200?text=Toy+B" },
  { id: 3, name: "Limited Figure C", price: 29.99, img: "https://via.placeholder.com/200x200?text=Figure+C" }
];
